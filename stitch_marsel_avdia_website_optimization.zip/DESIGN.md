---
name: Serene Clinical Excellence
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#42474d'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#72787e'
  outline-variant: '#c2c7ce'
  surface-tint: '#3f627e'
  primary: '#3c5f7b'
  on-primary: '#ffffff'
  primary-container: '#557895'
  on-primary-container: '#fcfcff'
  inverse-primary: '#a7cbeb'
  secondary: '#8c4f10'
  on-secondary: '#ffffff'
  secondary-container: '#fdad67'
  on-secondary-container: '#763f00'
  tertiary: '#565e58'
  on-tertiary: '#ffffff'
  tertiary-container: '#6f7770'
  on-tertiary-container: '#f7fff6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cbe6ff'
  primary-fixed-dim: '#a7cbeb'
  on-primary-fixed: '#001e30'
  on-primary-fixed-variant: '#254a65'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#ffb77b'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#6d3a00'
  tertiary-fixed: '#dde5dc'
  tertiary-fixed-dim: '#c1c9c1'
  on-tertiary-fixed: '#161d18'
  on-tertiary-fixed-variant: '#414943'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
  powder-blue: '#5A7D9A'
  copper-accent: '#B87333'
  warm-grey: '#6B6763'
  cream-surface: '#F9F8F5'
  sage-tint: '#E9F0E9'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  section-gap: 120px
  section-gap-mobile: 64px
  gutter: 24px
  container-max: 1140px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The visual identity of the design system is rooted in the concept of **Reassured Authority**. It is designed to bridge the gap between clinical excellence and empathetic care, specifically tailored for a psychiatric and psychotherapeutic practice. 

The aesthetic follows a **Modern / Corporate** direction with strong influences from **Minimalism**. By prioritizing legibility and vast negative space, the interface reduces cognitive load for patients who may be experiencing distress. The design evokes a sense of "clinical quietude"—a space that feels both institutional and deeply welcoming. High-quality editorial typography is paired with a soft, organic color palette to ensure the brand feels premium, established, and safe.

## Colors

The palette is intentionally de-saturated to project a calming atmosphere. 

- **Primary (Powder Blue):** Used for primary navigation, clinical section headers, and stable UI elements. It represents trust and professional stability.
- **Secondary (Copper):** Reserved for high-priority calls to action (e.g., "Prenota una visita"). It provides a warm, human contrast to the cooler clinical tones.
- **Neutral (Cream Surface):** Instead of pure white, a warm cream is used as the base background to avoid visual "glare" and provide a more inviting, tactile feel.
- **Sage Tint:** Used for secondary containers and informational backgrounds (e.g., FAQ cards) to create subtle tonal shifts without introducing new hue stress.

## Typography

This design system employs a sophisticated serif/sans-serif pairing to communicate both heritage and modernity.

- **Playfair Display** is the "voice of the clinician." It is used for headlines to convey experience, wisdom, and a high-end editorial feel.
- **Inter** is the "voice of clarity." It provides a neutral, highly legible foundation for clinical descriptions, forms, and instructions. 

Use `display-hero` for the doctor's name and primary landing statements. Ensure `body-lg` is the default for clinical explanations to improve accessibility for older patients or those with visual fatigue.

## Layout & Spacing

The layout philosophy is built on **Generous Breathing Room**. 

- **Grid:** Use a 12-column fixed grid for desktop (1140px max-width) and a 4-column fluid grid for mobile.
- **Rhythm:** Vertical spacing between sections should be exceptionally wide (`120px`) to prevent information overload.
- **Safe Areas:** Maintain minimum 24px margins on mobile devices.
- **Alignment:** Use a mix of centered hero sections for impact and left-aligned body text for maximum reading efficiency.

## Elevation & Depth

To maintain a clean and non-threatening medical environment, the design system avoids heavy shadows and skeuomorphism. Depth is achieved through:

1.  **Tonal Tiers:** Using `cream-surface` for the main background and `sage-tint` for secondary content containers.
2.  **Low-Contrast Outlines:** Instead of shadows, use 1px borders in a slightly darker shade of the background (e.g., a muted `tertiary-color`) to define cards.
3.  **Soft Ambient Depth:** If a shadow is required for a floating CTA or a modal, use a "Tinted Shadow"—a very soft, blurred shadow (20px blur, 5% opacity) that uses the `powder-blue` hue instead of pure black.

## Shapes

The shape language is **Soft and Approachable**. 

Sharp corners are avoided to reduce the "clinical coldness" often associated with medical institutions. 
- **Standard UI elements** (buttons, inputs): Use `0.5rem` (8px) corner radius.
- **Large containers** (cards, images): Use `rounded-lg` (16px) or `rounded-xl` (24px) for a gentler, more modern appearance.
- **CTAs:** May use "Pill" shapes (fully rounded) to maximize their organic, click-friendly feel.

## Components

### Buttons
- **Primary (Appointment):** Copper background, white text, pill-shaped. High-contrast.
- **Secondary (Inquiry):** Powder-blue border, powder-blue text, soft-rounded.
- **Tertiary (Ghost):** Underlined text for less critical links like "Read More."

### Cards
Cards should have no background (transparent) with a subtle `sage-tint` border, or a `sage-tint` background with no border. This "flat card" approach keeps the UI light.

### Form Fields
Inputs should use the `cream-surface` with a thin `warm-grey` border. Labels must be clearly positioned above the field in `label-sm` to ensure the user always knows what information is required.

### Contact Bar (Mobile)
A persistent footer bar on mobile devices containing two primary actions: "WhatsApp" (Icon-only or small label) and "Prenota" (Large Copper Button). This ensures help is always one tap away.

### Lists & FAQs
Use chevron-driven accordions for FAQs. The "Condition cards" (e.g., Depression, Anxiety) should use a subtle hover state that slightly intensifies the background color to provide interactive feedback.